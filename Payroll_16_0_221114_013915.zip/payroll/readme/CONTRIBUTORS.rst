* Odoo SA <info@odoo.com>
* David James <david@djdc.net.au>
* Hilar AK <hilarak@gmail.com>
* Nimarosa (Nicolas Rodriguez) <nicolarsande@gmail.com>
* Henrik Norlin (@appstogrow)
